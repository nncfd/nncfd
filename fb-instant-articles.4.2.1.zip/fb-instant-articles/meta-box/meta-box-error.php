<?php
/**
 * Facebook Instant Articles for WP.
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @package default
 */
?>
<p>An unkown error occurred while transforming the article. Please verify your rules configuration is correct.</p>
